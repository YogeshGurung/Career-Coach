import { CardService } from './../@core/services/card.service';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './../@core/services/auth.service';

@Component({
    selector: 'app-landing',
    templateUrl: './landing.component.html',
    styleUrls: ['./landing.component.scss']
})
export class LandingComponent {
    constructor(protected router: Router, public authService: AuthService, protected cardService: CardService) {
        console.log(this.cardService.getItemsList());
    }

    navigateTo(URL: string) {
        this.router.navigate([URL]);
    }
}
