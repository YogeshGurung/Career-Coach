import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-payment',
    templateUrl: './payment.component.html',
    styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
    paymentClicked = false;
    clickedOption: string = '';

    constructor() {}

    ngOnInit() {}

    optionClicked(paymentName: string) {
        this.clickedOption = paymentName;
        this.paymentClicked = true;
    }
}
