import { LocalStorageService } from './local-storage.service';
import { Injectable, NgZone } from '@angular/core';
import 'firebase/auth';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';

import { Router } from '@angular/router';

interface ICareerCard {
    level1: [];
    level2: [];
}

@Injectable({
    providedIn: 'root'
})
export class CardService {
    userId: any;
    private dbPath = '/cards';
    // careerCardList: AngularFireList<ICareerCard> = null;

    constructor(public db: AngularFireDatabase, public afAuth: AngularFireAuth, public router: Router, public ngZone: NgZone, protected localStorageService: LocalStorageService) {
        this.afAuth.authState.subscribe((user: any) => {
            if (user) this.userId = user.uid;
        });
    }

    getItemsList(): any {
        if (!this.userId) return;
        // const items = this.db.doc(`items/${this.userId}`);
    }
}
