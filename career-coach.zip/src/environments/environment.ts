export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: 'AIzaSyDvH4-5JMBfabObM5MMZph5M7AK7v666A8',
        authDomain: 'career-coach-4954d.firebaseapp.com',
        projectId: 'career-coach-4954d',
        storageBucket: 'career-coach-4954d.appspot.com',
        messagingSenderId: '141294000648',
        appId: '1:141294000648:web:e7b24a1a483281dec50fbd',
        measurementId: 'G-D2VR41YXT9'
    }
};
